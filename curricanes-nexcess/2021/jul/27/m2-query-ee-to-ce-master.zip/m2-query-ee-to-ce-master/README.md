# m2-query-ee-to-ce
sql query to convert db structure from Magento 2 EE to CE
